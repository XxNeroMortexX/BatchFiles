How to Create Shortcut for Windows Taskbar to Batchfile.

1.) Create a shortcut to the batch file.
2.) Right-click on the shortcut, Properties, write into the start of the target field "explorer.exe " without Quotes, click Apply. [Windows will later change that automatically to C:\Windows\explorer.exe and this is not a problem]
3.) Optional: add ICON, with shortcut Properties window Open Click on "Change Icon..."  & can use any Custom ICON or the "Everquest.ico" File i Included, click Apply & OK.
4.) right-click on the shortcut and select "Pin to taskbar" OR "Pin to Start"
5.) right-click on the shortcut in "Taskbar OR Start Menu", Properties, remove "C:\Windows\explorer.exe " OR "explorer.exe", click Apply & OK.
6.) All DOne now how Shortcut to Batchfile with an Custom Icon.